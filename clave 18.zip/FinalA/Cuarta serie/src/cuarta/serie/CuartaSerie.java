/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cuarta.serie;
import java.util.Scanner;
/**
 *
 * @author estudiante
 */
public class CuartaSerie {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int valor;
        
        System.out.println("ingrese un numero");
        Scanner D1 = new Scanner(System.in);
        valor = D1.nextInt();
        
        for (valor=0; valor<=10; valor ++){
            System.out.print(valor+10);
        // TODO code application logic here
    }
            
        }
}
