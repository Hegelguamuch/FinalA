/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primera.serie;

/**
 *
 * @author estudiante
 */
public class PrimeraSerie {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String Nombre= "Angel Josué Guamuch Gonzalez";
        String Grado = "5to.Baco A";
        
        System.out.println("Mi nombre es " + Nombre +" del grado de "+Grado);
                
        // TODO code application logic here
    }
    
}
